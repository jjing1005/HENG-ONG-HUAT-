/* scroll‑reveal */
function revealTimelineItems(){
  const items=document.querySelectorAll('.timeline-item');
  const trigger=window.innerHeight*0.85;
  items.forEach(item=>{
    if(item.getBoundingClientRect().top<trigger){
      item.classList.add('show');
    }
  });
}
window.addEventListener('scroll',revealTimelineItems);
window.addEventListener('load',revealTimelineItems);

/* click to expand / collapse */
/* click to toggle, but keep ONE card open */
document.querySelectorAll('.timeline-item').forEach(item => {
  item.addEventListener('click', () => {
    const isAlreadyExpanded = item.classList.contains('expanded');

    // 1. Collapse all expanded items
    document.querySelectorAll('.timeline-item.expanded').forEach(openCard => {
      openCard.classList.remove('expanded');
    });

    // 2. If clicked item wasn't already open, wait 300ms before expanding it
    if (!isAlreadyExpanded) {
      setTimeout(() => {
        item.classList.add('expanded');
      }, 400); // matches the collapse animation duration
    }
  });
});

document.getElementById("chor15").addEventListener("click", () => {
  // your usual expand/collapse code can stay here if needed

  // mark completion & show certificate
  onChor15Complete();
});
// ✅ When user clicks or finishes Chor 15
  function onChor15Complete() {
    localStorage.setItem("chor15Done", "true");
    promptAndShowCertificate();
  }

  // ✅ Show certificate
  function promptAndShowCertificate() {
    const userName = prompt("🎉 Enter your name for the certificate:");
    if (!userName) return;

    document.getElementById("username").innerText = userName;
    document.getElementById("dateIssued").innerText = new Date().toLocaleDateString();
    document.getElementById("certificateSection").style.display = "block";

    // Optionally scroll to certificate
    document.getElementById("certificateSection").scrollIntoView({ behavior: "smooth" });
  }

  // ✅ Run on page load: check if already completed
  // window.addEventListener("load", () => {
  //   if (localStorage.getItem("chor15Done") === "true") {
  //     promptAndShowCertificate();
  //   }
  // });

  // ✅ Download PNG
  function downloadCertificate() {
    html2canvas(document.querySelector(".certificate")).then(canvas => {
      let link = document.createElement("a");
      link.download = "certificate.png";
      link.href = canvas.toDataURL("image/png");
      link.click();
    });
  }
