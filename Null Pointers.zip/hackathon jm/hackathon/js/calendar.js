let userPoints = 100;

// DOM references
const grid = document.getElementById('grid');
const titleE = document.getElementById('title');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const popup = document.getElementById('popup');
const festName = document.getElementById('festName');
const festInfo = document.getElementById('festInfo');
const closeBtn = document.getElementById('closeBtn');
const details = document.getElementById('details');
const dName   = document.getElementById('dName');
const dInfo   = document.getElementById('dInfo');
const dImg = document.getElementById('dImg');

const pkgBox = document.getElementById('festivalPackage');
const pkgName = document.getElementById('pkgName');
const pkgPoints = document.getElementById('pkgPoints');
const pkgDesc = document.getElementById('pkgDesc');
const pkgBookBtn = document.getElementById('pkgBookBtn');
const bookingStatus = document.getElementById('bookingStatus');

// Festival data
const festivals = [
  { date: '2025-02-01', 
    name: 'Chor 1 (Day 1) - Welcoming the New Year ', 
    info: 'Chor 1 marks the official start of Chinese New Year. Families dress in new clothes, visit elders to wish them prosperity, and avoid using negative words. It is a day filled with lion dances, fireworks, and giving red packets (angpao) to children and unmarried adults.', 
    img: 'images/festival-cny.jpg',
    package: {                                // ⬅︎ put the package data here
      name:  'Penang CNY Cultural Tour',      // ← package name
      description: 'Festive walk through George Town lantern streets, lion‑dance shows and food tasting.',
      points: 50,                             // points needed to book
      img: 'images/cny-pkg.jpg'               // (optional) separate hero image for the package
    }
  },
  { date: '2025-02-02', 
    name: "Chor 2 (Day 2) - Visit the Wife's Family", 
    info: 'On Chor 2, married daughters return to their parental homes with gifts and angpao to visit their families. It’s a day for reunions and gratitude, often filled with laughter, big meals, and exchanging blessings between in-laws and extended family.', 
    img: 'images/festival-qingming.jpg' },
  { date: '2025-02-03', 
    name: 'Chor 3 (Day 3) - Day of Arguments & Temple Visits', 
    info: "Known as the 'Day of the Red Mouth' (赤口), it's believed to be prone to quarrels, so many avoid social visits. Instead, some visit temples for blessings and fortune readings. In Malaysia, this is a popular day for praying to deities and ancestors.",
    img: 'images/festival-hariRaya.png' },
  { date: '2025-02-04', 
    name: 'Chor 4 (Day 4) - Welcoming the Kitchen God', 
    info: 'Chor 4 is traditionally for welcoming back the Kitchen God and other deities to the household. Offerings like fruits and incense are made to ensure blessings for the year ahead. It’s also a quiet day to reset after early celebrations.',
    img: 'images/festival-deepavali.jpeg' },
  { date: '2025-02-05', 
    name: 'Chor 5 (Day 5) - Welcoming the God of Wealth', 
    info: 'Early in the morning, families perform rituals and set off firecrackers to welcome the God of Wealth (财神). Businesses often reopen on this day with ceremonies to bring prosperity, making it an important day for merchants and entrepreneurs.',
    img: 'images/festival-nationalDay.jpg' }
];

const defaultPackage = {
  name: 'Explore Malaysia Special',
  info: 'Discover hidden gems across Malaysia with flexible travel dates. Perfect for casual explorers!',
  img: 'images/default.jpg',
  points: 20
};

const travelPackages = [
  {
    name: 'Sabah Nature Escape',
    description: 'Explore Mount Kinabalu and island-hop around Sabah’s pristine beaches.',
    points: 60,
    img: 'images/pkg-kotakinabalu.jpeg'
  },
]

// Calendar state
let view = new Date();
view.setDate(1);
const todayStr = new Date().toISOString().split('T')[0];

// Rendering
function render() {
  grid.innerHTML = '';
  titleE.textContent = view.toLocaleDateString('default', { month: 'long', year: 'numeric' });

  const y = view.getFullYear();
  const m = view.getMonth();
  const firstDow = new Date(y, m, 1).getDay();
  const daysInMonth = new Date(y, m + 1, 0).getDate();
  const daysPrev = new Date(y, m, 0).getDate();

  for (let i = firstDow - 1; i >= 0; i--) {
    grid.appendChild(dayCell(daysPrev - i, 'other'));
  }

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const fest = festivals.find(f => f.date === dateStr);
    const cell = dayCell(d, dateStr === todayStr ? 'today' : '');

    if (fest) {
  cell.appendChild(dot());
  cell.onclick = () => {details.classList.remove('default');
    showDetails(fest);
  };
}
else {
  cell.onclick = () => showDetails(defaultPackage);
}

    grid.appendChild(cell);
  }

  const totalCells = grid.children.length;
  for (let i = totalCells; i < 42; i++) {
    grid.appendChild(dayCell(i - totalCells + 1, 'other'));
  }
}

function dayCell(num, extra = '') {
  const div = document.createElement('div');
  div.className = 'day ' + extra;
  div.textContent = num;
  return div;
  
}

function dot() {
  const span = document.createElement('span');
  span.className = 'dot';
  return span;
}

// Popup handling
function showDetails(fest) {
  dName.textContent = fest.name;
  dInfo.textContent = fest.info;
  dImg.src = fest.img;
  dImg.alt = fest.name;
  details.classList.remove('hidden');

  // Festival package logic
  if (fest.package) {
    pkgName.textContent = fest.package.name;
    pkgPoints.textContent = fest.package.points;
    pkgDesc.textContent = fest.package.description;
    bookingStatus.textContent = '';
    pkgBox.classList.remove('hidden');

    pkgBookBtn.onclick = () => {
      if (userPoints >= fest.package.points) {
        userPoints -= fest.package.points;
        bookingStatus.textContent = `✅ Booked "${fest.package.name}" successfully! Remaining points: ${userPoints}`;
        bookingStatus.style.color = 'green';
      } else {
        bookingStatus.textContent = `❌ Not enough points! You need ${fest.package.points - userPoints} more.`;
        bookingStatus.style.color = 'red';
      }
    };
  } else {
    pkgBox.classList.add('hidden');
  }
}

function renderTravelPackages() {
  const container = document.getElementById('packageList');
  travelPackages.forEach(pkg => {
    const card = document.createElement('div');
    card.className = 'package-card';
    card.innerHTML = `
      <img src="${pkg.img}" alt="${pkg.name}">
      <div class="content">
        <h4>${pkg.name}</h4>
        <p>${pkg.description}</p>
        <p><strong>${pkg.points} points</strong></p>
        <button>Book now</button>
      </div>
    `;
    container.appendChild(card);
  });
}

const items = document.querySelectorAll('.timeline-item');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, { threshold: 0.1 });

    items.forEach(item => {
      observer.observe(item);
    });

// Navigation
prevBtn.onclick = () => { view.setMonth(view.getMonth() - 1); render(); };
nextBtn.onclick = () => { view.setMonth(view.getMonth() + 1); render(); };

// Boot
render();
renderTravelPackages();